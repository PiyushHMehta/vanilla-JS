document.addEventListener('DOMContentLoaded', () => {
    const checkoutBtn = document.getElementById('checkoutBtn');

    checkoutBtn.addEventListener('click', () => {
        const provider = new firebase.auth.GoogleAuthProvider();
        firebase.auth().signInWithPopup(provider)
            .then((result) => {
                const user = result.user;
                const username = user.displayName;
                const email = user.email;

                let numberOfPieces = prompt("Enter the number of pieces:");
                numberOfPieces = parseInt(numberOfPieces, 10);

                if (isNaN(numberOfPieces) || numberOfPieces <= 0) {
                    alert("Please enter a valid number of pieces.");
                    return;
                }

                firebase.firestore().collection('orders').add({
                    username: username,
                    email: email,
                    numberOfPieces: numberOfPieces,
                    timestamp: new Date()
                })
                .then(() => {
                    fetch('/api/orders', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            username: username,
                            email: email,
                            numberOfPieces: numberOfPieces
                        })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert('Order placed successfully!');
                        } else {
                            alert('Error placing order: ' + data.message);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
                })
                .catch(error => {
                    console.error('Error adding document: ', error);
                });
            })
            .catch((error) => {
                console.error('Error during Google sign-in: ', error);
            });
    });
});
