const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const { db } = require('./config');
const axios = require('axios');

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, '../public')));

// API endpoint to handle orders
app.post('/api/orders', async (req, res) => {
  try {
    const { username, email, numberOfPieces } = req.body;

    // Add order to Firestore
    await db.collection('orders').add({
      username: username,
      email: email,
      numberOfPieces: numberOfPieces,
      timestamp: new Date()
    });

    // Send WhatsApp message
    const phoneNumber = '+918591039546'; // Replace with the owner's phone number
    const message = `New order from ${username}. Number of pieces: ${numberOfPieces}`;
    const whatsappUrl = `https://api.whatsapp.com/send?phone=${phoneNumber}&text=${encodeURIComponent(message)}`;

    // Open WhatsApp chat (alternatively, you can use a service like Twilio for sending messages)
    await axios.get(whatsappUrl);

    res.json({ success: true });
  } catch (error) {
    console.error('Error handling order:', error);
    res.status(500).json({ success: false, message: 'Failed to place order' });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
